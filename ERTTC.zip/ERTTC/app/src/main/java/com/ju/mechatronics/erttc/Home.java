package com.ju.mechatronics.erttc;

import android.content.Intent;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.view.View;
import android.view.View.OnClickListener;


public class Home extends AppCompatActivity {
GlobalVariables globalVariables;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        final

        FloatingActionButton NewDesign= (FloatingActionButton) findViewById(R.id.create);
        NewDesign.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Intent = new Intent(Home.this,New_Design.class);
                startActivity(Intent);

            }
        });
    }
}
